using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Windows;
using Autodesk.Revit.DB;
using GreenChainz.Revit.Models;
using GreenChainz.Revit.Services;

namespace GreenChainz.Revit.UI
{
    public partial class AuditResultsWindow : Window
    {
        private readonly AuditService _auditService;
        private readonly Document _doc;

        public AuditResultsWindow(AuditService auditService, Document doc)
        {
            InitializeComponent();
            _auditService = auditService;
            _doc = doc;
        }

        private async void BtnRunAudit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TxtStatus.Text = "Scanning project... Please wait.";
                BtnRunAudit.IsEnabled = false;
                ResultsPanel.Visibility = Visibility.Collapsed;

                AuditResult result = await _auditService.RunAuditAsync(_doc);

                if (result.Success)
                {
                    TxtScore.Text = $"{result.TotalCarbonScore:N2} kgCO2e";
                    TxtRating.Text = result.Rating;
                    
                    // Color code the rating
                    if (result.Rating == "A") TxtRating.Foreground = System.Windows.Media.Brushes.Green;
                    else if (result.Rating == "B") TxtRating.Foreground = System.Windows.Media.Brushes.Orange;
                    else TxtRating.Foreground = System.Windows.Media.Brushes.Red;

                    ListRecommendations.ItemsSource = result.Recommendations;
                    
                    ResultsPanel.Visibility = Visibility.Visible;
                    TxtStatus.Text = result.Message;
                }
                else
                {
                    TxtStatus.Text = "Audit failed: " + result.Message;
                }
            }
            catch (Exception ex)
            {
                TxtStatus.Text = "Error: " + ex.Message;
            }
            finally
            {
                BtnRunAudit.IsEnabled = true;
            }
        }

        private void BtnClose_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
