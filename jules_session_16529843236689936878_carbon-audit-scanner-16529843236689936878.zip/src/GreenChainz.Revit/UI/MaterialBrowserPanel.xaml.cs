using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using Autodesk.Revit.UI;
using GreenChainz.Revit.Models;
using GreenChainz.Revit.Services;
using GreenChainz.Revit.Utils;

namespace GreenChainz.Revit.UI
{
    public partial class MaterialBrowserPanel : UserControl, IDockablePaneProvider
    {
        private MaterialService _service;
        private ObservableCollection<Material> _allMaterials;
        private ICollectionView _filteredView;
        
        // External Event Handling
        private ExternalEvent _externalEvent;
        private MaterialCreationHandler _handler;

        public MaterialBrowserPanel()
        {
            InitializeComponent();
            _service = new MaterialService();
            _allMaterials = new ObservableCollection<Material>();

            // Setup External Event
            _handler = new MaterialCreationHandler();
            _externalEvent = ExternalEvent.Create(_handler);
            
            // Setup loading
            this.Loaded += MaterialBrowserPanel_Loaded;
        }

        private async void MaterialBrowserPanel_Loaded(object sender, RoutedEventArgs e)
        {
            if (_allMaterials.Count > 0) return; // Already loaded

            try
            {
                var data = await _service.GetMaterialsAsync();
                foreach (var item in data)
                {
                    _allMaterials.Add(item);
                }

                _filteredView = CollectionViewSource.GetDefaultView(_allMaterials);
                _filteredView.Filter = FilterMaterials;
                MaterialsGrid.ItemsSource = _filteredView;
            }
            catch (Exception ex)
            {
                // In a real app, log or show error
                // System.Diagnostics.Debug.WriteLine($"Error loading materials: {ex.Message}");
            }
        }

        public void SetupDockablePane(DockablePaneProviderData data)
        {
            data.FrameworkElement = this;
            data.InitialState = new DockablePaneState
            {
                DockPosition = DockPosition.Tabbed,
                TabBehind = DockablePanes.BuiltInDockablePanes.ProjectBrowser
            };
        }

        private bool FilterMaterials(object obj)
        {
            if (obj is Material material)
            {
                // 1. Text Search
                string searchText = SearchBox.Text?.ToLower() ?? "";
                bool matchesSearch = string.IsNullOrEmpty(searchText) || 
                                     material.Name.ToLower().Contains(searchText) || 
                                     material.Manufacturer.ToLower().Contains(searchText);

                // 2. Category Filter
                string selectedCategory = (CategoryFilter.SelectedItem as ComboBoxItem)?.Content?.ToString();
                bool matchesCategory = selectedCategory == "All" || material.Category == selectedCategory;

                return matchesSearch && matchesCategory;
            }
            return false;
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            _filteredView?.Refresh();
        }

        private void CategoryFilter_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            _filteredView?.Refresh();
        }

        private void MaterialsGrid_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Binding handles most interaction, but just in case we need logic here
            bool hasSelection = MaterialsGrid.SelectedItem != null;
            AddToProjectBtn.IsEnabled = hasSelection;
        }

        private void AddToProjectBtn_Click(object sender, RoutedEventArgs e)
        {
            if (MaterialsGrid.SelectedItem is Material selectedMaterial)
            {
                // Pass data to handler
                _handler.MaterialToCreate = selectedMaterial;
                
                // Raise the event to run entirely inside Revit's API context
                _externalEvent.Raise();
            }
        }
    }
}
