using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using Autodesk.Revit.ApplicationServices;
using GreenChainz.Revit.Models;
using GreenChainz.Revit.Utils;

namespace GreenChainz.Revit.Services
{
    public class MaterialService
    {
        // In a real app, this would use HttpClient to call the API
        // private readonly HttpClient _httpClient;

        public async Task<List<Models.Material>> GetMaterialsAsync()
        {
            // Simulate API delay
            await Task.Delay(500);

            // Return mock data for now
            return new List<Models.Material>
            {
                new Models.Material
                {
                    Id = "1",
                    Name = "Recycled Steel Beam",
                    Category = "Steel",
                    CarbonScore = 120.5,
                    Price = 450.00m,
                    Certifications = "ISO 14001, EPD",
                    Manufacturer = "Green Steel Co.",
                    Description = "High strength recycled steel beam."
                },
                new Models.Material
                {
                    Id = "2",
                    Name = "Low-Carbon Concrete Block",
                    Category = "Concrete",
                    CarbonScore = 15.2,
                    Price = 5.50m,
                    Certifications = "GreenGuard",
                    Manufacturer = "EcoBuild Concrete",
                    Description = "Concrete block with 40% fly ash replacement."
                },
                new Models.Material
                {
                    Id = "3",
                    Name = "FSC Certified Oak Flooring",
                    Category = "Wood",
                    CarbonScore = 5.8,
                    Price = 85.00m,
                    Certifications = "FSC, LEED Compliant",
                    Manufacturer = "Forest First",
                    Description = "Sustainably harvested oak flooring."
                },
                new Models.Material
                {
                    Id = "4",
                    Name = "Wool Insulation Batts",
                    Category = "Insulation",
                    CarbonScore = 2.1,
                    Price = 22.00m,
                    Certifications = "Declare Label",
                    Manufacturer = "Natural Warmth",
                    Description = "Natural wool insulation, treated with borates."
                },
                 new Models.Material
                {
                    Id = "5",
                    Name = "Recycled Aluminum Panel",
                    Category = "Metal",
                    CarbonScore = 85.0,
                    Price = 120.00m,
                    Certifications = "Cradle to Cradle",
                    Manufacturer = "AluCycle",
                    Description = "100% post-consumer recycled aluminum façade panel."
                }
            };
        }

        public void CreateRevitMaterial(Document doc, Application app, Models.Material apiMaterial)
        {
            using (Transaction t = new Transaction(doc, "Create Green Material"))
            {
                t.Start();

                // 1. Ensure Shared Parameters Exist
                SharedParameterHelper.CreateSharedParameters(doc, app);

                // 2. Check if material exists
                Autodesk.Revit.DB.Material revitMaterial = null;
                FilteredElementCollector collector = new FilteredElementCollector(doc);
                var materials = collector.OfClass(typeof(Autodesk.Revit.DB.Material)).ToElements();
                
                foreach (Autodesk.Revit.DB.Material m in materials)
                {
                    if (m.Name.Equals(apiMaterial.Name, StringComparison.OrdinalIgnoreCase))
                    {
                        revitMaterial = m;
                        break;
                    }
                }

                if (revitMaterial == null)
                {
                    ElementId matId = Autodesk.Revit.DB.Material.Create(doc, apiMaterial.Name);
                    revitMaterial = doc.GetElement(matId) as Autodesk.Revit.DB.Material;
                }

                // 3. Set standard properties
                revitMaterial.MaterialClass = apiMaterial.Category;

                // 4. Set Shared Parameters
                // We need to find the shared params we bound.
                // Since they are instance parameters bound to Material category, we access them from the Material element.
                
                Parameter carbonParam = revitMaterial.LookupParameter("GC_CarbonScore");
                if (carbonParam != null && !carbonParam.IsReadOnly) carbonParam.Set(apiMaterial.CarbonScore);

                Parameter manufacturerParam = revitMaterial.LookupParameter("GC_Supplier"); // Mapped directly
                if (manufacturerParam != null && !manufacturerParam.IsReadOnly) manufacturerParam.Set(apiMaterial.Manufacturer);

                Parameter certParam = revitMaterial.LookupParameter("GC_Certifications");
                if (certParam != null && !certParam.IsReadOnly) certParam.Set(apiMaterial.Certifications);

                // 5. Appearance (Simple Color)
                // Green for really low, Yellow for medium, fallback Grey
                Color displayColor = new Color(128, 128, 128);
                if (apiMaterial.CarbonScore < 10) displayColor = new Color(0, 200, 0); // Green
                else if (apiMaterial.CarbonScore < 50) displayColor = new Color(200, 200, 0); // Yellow
                
                revitMaterial.Color = displayColor;

                t.Commit();
            }
        }
    }
}
