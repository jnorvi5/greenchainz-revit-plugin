using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Autodesk.Revit.DB;
using GreenChainz.Revit.Models;

namespace GreenChainz.Revit.Services
{
    public class AuditService
    {
        private readonly ApiClient _apiClient;

        public AuditService()
        {
            _apiClient = new ApiClient();
        }

        public List<ProjectMaterial> ScanProject(Document doc)
        {
            List<ProjectMaterial> projectMaterials = new List<ProjectMaterial>();
            
            // Filter for elements that are likely to have materials and geometry
            FilteredElementCollector collector = new FilteredElementCollector(doc);
            ICollection<Element> elements = collector
                .WhereElementIsNotElementType()
                .WhereElementIsViewIndependent()
                .ToElements();

            Dictionary<string, ProjectMaterial> materialSummary = new Dictionary<string, ProjectMaterial>();

            foreach (Element element in elements)
            {
                if (element.Category == null) continue;
                // Exclude some categories if necessary, e.g., cameras, lines, etc.
                // For now, we process everything that has material quantities.

                // Get materials from the element
                foreach (ElementId matId in element.GetMaterialIds(false))
                {
                    Autodesk.Revit.DB.Material mat = doc.GetElement(matId) as Autodesk.Revit.DB.Material;
                    if (mat == null) continue;

                    double volume = element.GetMaterialVolume(matId); // Cubic feet

                    if (volume > 0.0001)
                    {
                        if (materialSummary.ContainsKey(mat.Name))
                        {
                            materialSummary[mat.Name].Quantity += volume;
                        }
                        else
                        {
                            materialSummary[mat.Name] = new ProjectMaterial
                            {
                                MaterialName = mat.Name,
                                Category = mat.MaterialClass,
                                Quantity = volume,
                                Unit = "cubic ft" // Revit internal unit for volume
                            };
                        }
                    }
                }
            }

            return materialSummary.Values.ToList();
        }

        public async Task<AuditResult> RunAuditAsync(Document doc)
        {
            var materials = ScanProject(doc);

            var request = new AuditRequest
            {
                ProjectName = doc.Title,
                AuditDate = DateTime.Now,
                Materials = materials
            };

            return await _apiClient.SubmitAuditAsync(request);
        }
    }
}
