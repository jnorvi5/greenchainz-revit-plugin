using System;
using System.Collections.Generic;

namespace GreenChainz.Revit.Models
{
    public class ProjectMaterial
    {
        public string MaterialName { get; set; }
        public string Category { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
    }

    public class AuditRequest
    {
        public string ProjectName { get; set; }
        public DateTime AuditDate { get; set; }
        public List<ProjectMaterial> Materials { get; set; }
    }

    public class AuditResult
    {
        public double TotalCarbonScore { get; set; } // Total kgCO2e
        public string Rating { get; set; } // A, B, C, etc.
        public List<string> Recommendations { get; set; }
        public bool Success { get; set; }
        public string Message { get; set; }
    }
}
