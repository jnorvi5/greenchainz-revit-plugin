using System;

namespace GreenChainz.Revit.Models
{
    public class Material
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public string Category { get; set; }
        public double CarbonScore { get; set; } // kgCO2e/unit
        public decimal Price { get; set; }
        public string Certifications { get; set; }
        public string Manufacturer { get; set; }
        public string Description { get; set; }
    }
}
